# FPSBoost.ps1 - Aggressive Game Optimization Script

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "      ⚡ AGGRESSIVE FPS BOOST ⚡      "
Write-Host "=====================================" -ForegroundColor Cyan

# 1. Clean Temp, Prefetch, etc.
Write-Host "`nCleaning temporary files..." -ForegroundColor Yellow
$paths = @(
    "$env:TEMP\*",
    "C:\Windows\Temp\*",
    "C:\Windows\Prefetch\*",
    "$env:LOCALAPPDATA\Temp\*"
)
foreach ($path in $paths) {
    Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
}

# 2. Disable Non-Essential Services (Safe Mode)
Write-Host "`nDisabling unnecessary services..." -ForegroundColor Yellow
$services = @(
    "SysMain",
    "WSearch",
    "wuauserv",
    "bits",
    "Fax",
    "Spooler",
    "TrkWks",
    "WerSvc",
    "DiagTrack",
    "RetailDemo",
    "wisvc",
    "diagnosticshub.standardcollector.service",
    "PcaSvc",
    "XblAuthManager",
    "XblGameSave",
    "WMPNetworkSvc",
    "MapsBroker",
    "WbioSrvc",
    "lfsvc",
    "PhoneSvc",
    "RemoteRegistry",
    "SharedAccess"
)
foreach ($svc in $services) {
    try {
        Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue
        Write-Host "Stopped: $svc"
    } catch {
        Write-Host "Skipped or failed: $svc"
    }
}

# 3. Reduce Memory Usage (Working Set Trimming)
Write-Host "`nReducing memory usage..." -ForegroundColor Yellow
Get-Process | ForEach-Object {
    try {
        $_.Refresh()
        $proc = [System.Diagnostics.Process]::GetProcessById($_.Id)
        $proc.MinWorkingSet = 5MB
        $proc.MaxWorkingSet = 10MB
    } catch {}
}

# 4. Clear RAM (Garbage Collection)
Write-Host "`nClearing RAM using garbage collection..." -ForegroundColor Yellow
[System.GC]::Collect()
[System.GC]::WaitForPendingFinalizers()
[System.GC]::Collect()

# 5. Launch Optimization Apps
Write-Host "`nLaunching Quick CPU, ISLC, and Process Lasso (Free)..." -ForegroundColor Yellow

$quickCPU = "C:\Program Files\QuickCPU\QuickCPU.exe"
$islc = "C:\Program Files\ISLC\Intelligent standby list cleaner ISLC.exe"
$lasso = "C:\Program Files\Process Lasso\ProcessLasso.exe"

$apps = @(
    @{Path=$quickCPU; Name="Quick CPU"},
    @{Path=$islc; Name="ISLC"},
    @{Path=$lasso; Name="Process Lasso (Free)"}
)

foreach ($app in $apps) {
    if (Test-Path $app.Path) {
        Start-Process -FilePath $app.Path
        Write-Host "Launched: $($app.Name)"
    } else {
        Write-Host "Not found: $($app.Name) - Please check path."
    }
}

Write-Host "`n✅ FPS Boost Complete! Launch your game and enjoy higher performance." -ForegroundColor Green
